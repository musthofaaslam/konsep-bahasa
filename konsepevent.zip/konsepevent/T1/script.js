const butto = document.getElementById('changeColorBtn');
const paraf = document.getElementById('myParagraph');

butto.addEventListener('click', function () {
  paraf.style.color = 'purple';
});
